This role deploys and initializes Hashicorp Vault with Consul backend

Role variables
--------------

* Consul
  * Mandatory
    * `consul_bind_interface`: Which interface should be used for Consul
    * `consul_vip_address`: Under which IP address consul should be available (this role does not deploy keepalived)
  * Optional
    * `consul_docker_name`: Docker - under which name to run the Consul image (default: "consul")
    * `consul_docker_image`: Docker image for Consul (default: "consul")
    * `consul_docker_tag`: Docker image tag for Consul (default: "latest")
    * `consul_docker_volume`: Docker volume name for Consul data (default: "consul_data")
    * `consul_container.etc_hosts`: Dict of `{<hostname>:<ip_address>}` to be added to container /etc/hosts (default: Omitted)
    * `consul_extra_volumes`: List of `"<host_location>:<container_mountpoint>"`

* Vault
  * Mandatory
    * `vault_cluster_name`: Vault cluster name (e.g. "prod_cluster")
    * `vault_api_addr`: Vault [API addr](https://www.vaultproject.io/docs/configuration#api_addr) - Full URL including protocol and port (e.g. "http://127.0.0.1:8200")
    * `vault_bind_address`: Which IP address should Vault bind to
    * `vault_tls_key`: Path to TLS key to use by Vault
    * `vault_tls_cert`: Path to TLS cert to use by Vault
    * `vault_config_dir`: Directory into which to bind mount Vault configuration
    * `copy_self_signed_ca`: bool; copy a custom CA into the vault container

  * Optional
    * `consul_container.etc_hosts`: Dict; `{<hostname>:<ip_address>}` to be added to container /etc/host
s (default: Omitted)
    * `vault_extra_volumes`: List of `"<host_location>:<container_mountpoint>"`

* vault backend and backend HA
  * Mandatory
    * `vault_root_ca_name`: The common name for the RootCA
    * `vault_intermediate_ca_name`: The common name for the intermediateCA




Example playbook (used with OpenStack Kayobe)
---------------------------------------------

```
---
- name: Prepare for hashicorp-vault role
  any_errors_fatal: true
  gather_facts: true
  hosts: consul
  tasks:
    - name: Copy rootCA
      copy:
        content: "{{ external_ca_cert }}"
        dest: "{{ '/etc/pki/ca-trust/source/anchors/rootCA.crt' if ansible_os_family == 'RedHat' else '/usr/local/share/ca-certificates/rootCA.crt' }}"
        mode: 0600
        no_log: true
      become: true

    - name: update system CA
      become: true
      shell: "{{ 'update-ca-trust' if ansible_os_family == 'RedHat' else 'update-ca-certificates' }}"

    - name: Ensure /opt/kayobe/vault exists
      file:
        path: /opt/kayobe/vault
        state: directory

    - name: Template out tls key and cert
      vars:
        tls_files:
          - content: "{{ secrets_external_tls_cert }}"
            dest: "tls.cert"
          - content: "{{ secrets_external_tls_key }}"
            dest: "tls.key"
      copy:
        content: "{{ item.content }}"
        dest: "/opt/kayobe/vault/{{ item.dest }}"
        owner: 100
        group: 1001
        mode: 0600
      loop: "{{ tls_files }}"
      no_log: true
      become: true

- name: Run hashicorp-vault role
  any_errors_fatal: true
  gather_facts: true
  hosts: consul
  roles:
    - role: stackhpc.hashicorp.vault
      consul_bind_interface: "{{ internal_net_interface }}"
      consul_bind_ip: "{{ internal_net_ips[ansible_hostname] }}"
      consul_vip_address: "{{ internal_net_vip_address }}"
      vault_bind_address: "{{ external_net_ips[ansible_hostname] }}"
      vault_api_addr: "https://{{ external_net_fqdn }}:8200"
      vault_config_dir: "/opt/kayobe/vault"
```

Example post-config playbook to enable secrets engines:
```
---
- name: Vault post deployment config
  any_errors_fatal: true
  gather_facts: true
  hosts: vault
  tasks:
    - name: Enable vault secrets engines
      hashivault_secret_engine:
        url: "https://sparrow.cf.ac.uk:8200"
        token: "{{ secrets_vault_keys.root_token }}"
        name: pki
        backend: pki
      run_once: true
```

Example vault unseal playbook based on Kayobe's secrets.yml
```
---
- name: Unseal vault
  any_errors_fatal: true
  gather_facts: true
  hosts: vault
  tasks:
    - name: Unseal vault
      hashivault_unseal:
        url: "https://sparrow.cf.ac.uk:8200"
        keys: "{{ item }}"
      run_once: true
      with_items: "{{ secrets_vault_keys.unseal_keys_b64 }}"
      no_log: true
```

NOTE: secrets_external_tls_cert/key and external_ca_cert are variables in Kayobe's secrets.yml
